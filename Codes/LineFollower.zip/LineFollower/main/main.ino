#include "line_follower.h"

// Line follow object
LineFollower lineFollow;


void setup() {
  Serial.begin(115200);

  lineFollow.init();

}

void loop() {
  lineFollow.update(1);  // Forward direction

}
