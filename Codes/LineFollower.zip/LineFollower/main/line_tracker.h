#ifndef LINE_TRACKER_H
#define LINE_TRACKER_H

#include <Arduino.h>
#include "ir_array.h"

class LINEtracker {
public:
    LINEtracker();
       
    void init();

    // Compute and Return position
    float computePosition(const bool readings[]); 
    bool isLineLost(const bool readings[]);

    // Return ture if a perpendicular line is detected (all 8 IR sensors return 0)
    bool isPerpendicularLine(const bool readings[]);

    // Detect the junctions
    bool detectJunction(const bool irval[]);

private:
    // weights[ -4, -3, -2, -1, +1, +2, +3, +4]
    float weights[NUM_SENSORS];
};

#endif