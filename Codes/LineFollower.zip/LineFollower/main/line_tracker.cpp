#include "line_tracker.h"

LINEtracker::LINEtracker() {
    // Initialize all weights to 0; real setup happens in init()
    for (int i = 0; i < NUM_SENSORS; i++) {
        weights[i] = 0.0f;
    }
}

/// Modified for 8 sensors
void LINEtracker::init() {
    int half = NUM_SENSORS / 2;

    // weights: [-4, -3, -2, -1, +1, +2, +3, +4]
    for (int i = 0; i < NUM_SENSORS; i++) {
        if (i < half)
            weights[i] = i - half;       // -4 -3 -2 -1
        else
            weights[i] = i - half + 1;   // +1 +2 +3 +4
    }
}


float LINEtracker::computePosition(const bool readings[]) {
    float sumWeights = 0.0f;
    float count = 0.0f;

    for (int i = 0; i < NUM_SENSORS; i++) {
        // Count only if ir reading is 0 (White line = 0)
        if (!readings[i]) {
            sumWeights += weights[i];
            count += 1.0f;
        }
    }

    // Line lost( special case )
    if (count == 0) return 999.0f;   

    //Line position
    return sumWeights / count;       
}

// To be modified
bool LINEtracker::isLineLost(const bool readings[]) {
    for (int i = 0; i < NUM_SENSORS; i++)
        if (!readings[i]) {
          return false;
        }
    return true;
}


bool LINEtracker::isPerpendicularLine(const bool readings[]){
    for (int i = 0; i < NUM_SENSORS; i++)
        if (readings[i]) {
          return false;
        }
    return true;
}

// Detect Line Joints
bool LINEtracker::detectJunction(const bool irval[]) {
  bool leftsideIR = (!irval[0] || !irval[1] || !irval[2]);
  bool rightsideIR = (!irval[5] || !irval[6] || !irval[7]);
  bool midIR = (!irval[3] || !irval[4]);

  // Check whether the robot traversed a junction
  if (leftsideIR && midIR && rightsideIR) {
    // Junction detected
    return true;
  }
  
  // Junction not detected
  return false;
}

