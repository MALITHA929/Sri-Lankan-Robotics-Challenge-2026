#include "single_wallfollower.h"
#include "sharp_ir_array.h"
#include "stepper_motor.h"

const int sharpPins[] = {A8, A9, A10, A11, A12};

SINGLEWALLtracker walltracker;
PIDwallfollow pid;
SharpIRArray sensors(sharpPins, 5);
STEPPERcontroller steppers;

SINGLEWallFollower wallfollower(walltracker, pid, sensors, steppers);

void setup() {
  Serial.begin(115200);

  // Parametes for navigation
  bool start = true;
  int step = 1;
  wallfollower.init();

}

void loop() {
  if (step == 1){
    // Initial distance sensor reading
    

  }else if (step == 2){

  }else if (step == 3){

  }else if (step == 4){

  }else if (step == 5){

  }else if (step == 6){

  }else if (step == 7){

  }else if (step == 8){
    
  }else if (step == 9){

  }else if (step == 10){

  }else if (step == 11){

  }

}
