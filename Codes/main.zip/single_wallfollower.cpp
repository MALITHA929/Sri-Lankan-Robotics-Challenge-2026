#include "single_wallfollower.h"

SINGLEWallFollower::SINGLEWallFollower(SINGLEWALLtracker& wt,
                        PIDwallfollow& p,
                        SharpIRArray& s,
                        STEPPERcontroller& st)
                        : walltracker(wt), pid(p), sensors(s), steppers(st){
    baseSpeed = 90;
    loopDt = 0.0001f;   // 10 ms
}


void SINGLEWallFollower::init() {
    //////// Init hardware
    sensors.init();
    steppers.init();

    
    pid.reset();
    lastTime = millis();
}


void SINGLEWallFollower::update(bool rightWall) {

    // steppers.setSpeed(baseSpeed, baseSpeed);
    // steppers.runMotors(); 
    // Maintain fixed loop timing
    unsigned long now = millis();
    float dt = (now - lastTime) / 1000.0f;

    if (dt < loopDt) return;
    lastTime = now;

    //Read sensors
    sensors.update();

    int frontSensor, backSensor;

    if (rightWall) {
        frontSensor = 2;
        backSensor = 1;
    }else{
        frontSensor = 4;
        backSensor = 3;
    }

    float front = sensors.getDistance(frontSensor);
    Serial.print("f: ");
    Serial.println(front);

    float back  = sensors.getDistance(backSensor);
    Serial.println(back);
    // Compute wall error
    float error = walltracker.computeError(front, back);

    // PID output (steering)
    float steering = pid.compute(0.0f, error, dt);

    if (!rightWall) steering *= (-1);
    // Convert to motor speeds 
    float left  = baseSpeed + steering;
    float right = baseSpeed - steering;

    // Clamp speeds
    clampMotorSpeeds(left, right);


    steppers.setSpeed(left, right);
    // Apply speeds 
    // if (rightWall){
    //     steppers.setSpeed(left, right);
    // }else{
    //     steppers.setSpeed(right, left);
    // }
    
    steppers.runMotors();
}



// Clamp values to motor limits
void SINGLEWallFollower::clampMotorSpeeds(float& left, float& right)
{
    if (left > 255)  left = 255;
    if (left < -255) left = -255;
    if (right > 255)  right = 255;
    if (right < -255) right = -255;
}
