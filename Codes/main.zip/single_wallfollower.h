#ifndef SINGLE_WALLFOLLOWER
#define SINGLE_WALLFOLLOWER

#include "single_wall_tracker.h"
#include "PID_wallfollower.h"
#include "sharp_ir_array.h"
#include "stepper_motor.h"

// const int sharpPins[] = {A8, A9, A10, A11, A12};

class SINGLEWallFollower {

  public:
    SINGLEWallFollower(SINGLEWALLtracker& wt,
                        PIDwallfollow& p,
                        SharpIRArray& s,
                        STEPPERcontroller& st);

    void init();
    void update(bool rightWall);
  
  private:
    SINGLEWALLtracker& walltracker;
    PIDwallfollow& pid;
    SharpIRArray& sensors;
    STEPPERcontroller& steppers;

    float baseSpeed;

    unsigned long lastTime;
    float loopDt;   // seconds

    void clampMotorSpeeds(float& left, float& right);


};


#endif