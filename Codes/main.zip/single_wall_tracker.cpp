#include "single_wall_tracker.h"

SINGLEWALLtracker::SINGLEWALLtracker(): 
    desiredDistance(15.0f), Kd(1.0), Ka(10.0f),
    sensorSpacing(11.5f)
{}

float SINGLEWALLtracker::getDistance(float front, float back) {
    return front;
}

float SINGLEWALLtracker::getAngle(float front, float back) {
    return (back - front) / sensorSpacing;
}

float SINGLEWALLtracker::computeError(float front, float back) {

    float distance = getDistance(front, back);
    float angle = getAngle(front, back);

    float error_dist = desiredDistance - distance;
    float error_angle = angle;

    float error = Kd * error_dist + Ka * error_angle;

    Serial.print("Error: ");
    Serial.println(error);

    return error;
}