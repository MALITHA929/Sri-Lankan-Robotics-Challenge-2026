#include "stepper_motor.h"
#include "box_navigator.h"
#include "line_follower.h"
#include "sharp_ir_array.h"
#include "pi_communicator.h"
#include "box_insert_nav.h"
#include "robot_arm.h"
#include "dip_switch.h"
#include "wall_follower.h"
#include "task_1.h"

// Include our new Robot Strategy Classes
#include "robot1.h"
#include "robot2.h"
#include "robot3.h"

// --- GLOBAL HARDWARE OBJECTS ---
IRarray irsensors;
LINEtracker tracker;
PiCommunicator Picom;
STEPPERcontroller motors;           
BoxNavigator navigator(motors);     
LineFollower lineFollow(motors);

const int sharpPins[] = {A8, A9, A10, A11, A12};
SharpIRArray distanceSensors(sharpPins, 5);
BoxInsertNav insert;
RobotArm arm;
WallFollower wallFollow(motors, distanceSensors);
Task1 task1Nav(motors, distanceSensors, wallFollow);

// --- STRATEGY & CONTROL OBJECTS ---
DipSwitch dipSwitch;
Robot1 robot1;
Robot2 robot2;
Robot3 robot3;



void setup() {
  Serial.begin(115200);

  // Initialize all hardware components
  motors.init();       
  navigator.init();     
  lineFollow.init();    
  insert.init(22);
  wallFollow.init();
  arm.init(53, 51, 49, 47, 45);
  task1Nav.init();
  distanceSensors.init();
  // Initialize DIP Switch with your 3 specific pins
  dipSwitch.init(23, 25, 27); //22-1,24-2,26-3


  Serial.println("System Booted. Awaiting Strategy Selection...");
}

void loop() {
    // 1. Read the physical switch
    robot2.run(tracker, Picom, motors, navigator, lineFollow, distanceSensors, insert, arm, irsensors, wallFollow, task1Nav);

    // delay(2000);
    // int currentStrategy = dipSwitch.readMode();


    // // 2. Execute the selected strategy, passing the hardware objects by reference
    // switch (currentStrategy) {
    //     case 1:
    //         robot1.run(tracker, Picom, motors, navigator, lineFollow, distanceSensors, insert, arm, irsensors, wallFollow);
    //         break;
            
    //     case 2:
    //         robot2.run(tracker, Picom, motors, navigator, lineFollow, distanceSensors, insert, arm, irsensors, wallFollow);
    //         break;
            
    //     case 3:
    //         robot3.run(tracker, Picom, motors, navigator, lineFollow, distanceSensors, insert, arm, irsensors, wallFollow);
    //         break;
            
    //     default:
    //         // Safety fallback: Stop everything if switch is invalid
    //         motors.stop();
    //         insert.stop();
    //         Serial.println("Invalid Mode/Standby");
    //         break;
    // }
}