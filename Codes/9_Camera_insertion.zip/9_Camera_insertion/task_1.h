#ifndef TASK_1_H
#define TASK_1_H

#include <Arduino.h>
#include "stepper_motor.h"
#include "sharp_ir_array.h"
#include "wall_follower.h"
#include "line_tracker.h" 
#include "ir_array.h"

class Task1 {
public:
    int step;
    bool start;
    bool isComplete;
    bool task1finished =0;

    // Constructor requires references to the hardware
    Task1(STEPPERcontroller& motors, SharpIRArray& distanceSensors, WallFollower& wallFollow)
        : _motors(motors), _distanceSensors(distanceSensors), _wallFollow(wallFollow) 
    {
        step = 1;
        start = true;
        isComplete = false;
    }

    void init() {
        step = 1;
        start = true;
        isComplete = false;
    }

    void run(LINEtracker& tracker, IRarray& irsensors) {

        if (step == 1) {
            // Initial distance sensor reading
            if (start) {
                _distanceSensors.update();
                start = false;
            }

            // Follow the right wall until the gate is detected
            if (_distanceSensors.detectEntrance(false, true) && _distanceSensors.detectEntrance(false, false)){
                delay(100);
                _motors.runForward(100, 130);
                delay(100);
                _motors.turnLeft90();
                delay(100);

                start = true;
                step = 2;
                delay(100);
            } else {
                _wallFollow.followRightWall(16.5f);
                _wallFollow.updateSteppers();  
            }
        } 
        else if (step == 2) {
            if (start) {
                _distanceSensors.update();
                start = false;
            }

            if (_distanceSensors.getDistance(3) < 20.0f){
                while (!_distanceSensors.detectFrontWall()){
                    _wallFollow.followLeftWall(14.0f);
                    _wallFollow.updateSteppers();  
                }

                _motors.turnRight90();
                delay(100);

                step = 3;
                start = true;
            } else {
                _motors.setSpeed(100, 100);
                _motors.runMotors();
                delay(5);
                _distanceSensors.update();
            }
        } 
        else if (step == 3) {
            if (start) {
                _distanceSensors.update();

                while (!(_distanceSensors.getDistance(1) < 20.0f)){
                    _motors.setSpeed(100, 100);
                    _motors.runMotors();
                    delay(5);
                    _distanceSensors.update();
                }
                start = false;
            }

            if (_distanceSensors.detectFrontWall()){
                _motors.runBackward(100, 100);
                delay(100);
                _motors.turnLeft90();
                delay(100);

                step = 4;
                start = true;
            } else {
                _wallFollow.followRightWall(16.0f);    
                _wallFollow.updateSteppers(); 
            }
        } 
        else if (step == 4) {
            if (start) {
                _distanceSensors.update();
                start = false;
            }

            if (_distanceSensors.detectEntrance(true, true)){
                _motors.runForward(100, 250);
                delay(100);
                _motors.turnRight90();
                delay(100);

                step = 5;
                start = true;
            } else {
                _wallFollow.followRightWall(14.0f);
                _wallFollow.updateSteppers(); 
            }
        } 
        else if (step == 5){
          // Initial distance sensor reading
          if (start) {
            _distanceSensors.update();

            while ((_distanceSensors.getDistance(1) >= 30.0f) || (_distanceSensors.getDistance(2) >= 30.0f)){
              // Front wall is not yet detected
              _wallFollow.followLeftWall(10.0f);
              _wallFollow.updateSteppers(); 
            }

            start = false;
        }

          // Follow the right wall until the front wall is detected
        if (_distanceSensors.detectEntrance(true, true)){

          // Front wall is detected
          delay(100);

          _motors.runForward(100, 300);
          delay(100);
          _motors.turnLeft90();
          delay(100);
          // Go to the next step
          start = true;
          step = 6;
          }else{

          // Front wall is not yet detected
          _wallFollow.followLeftWall(10.0f);
          _wallFollow.updateSteppers();  
          }
        }
        else if (step == 6) {
            if (start) {
              // motors.runForward(100, 200);
              _distanceSensors.update();
              while (_distanceSensors.getDistance(3) >= 30.0f){
                _wallFollow.followRightWall(10.0f);
                _wallFollow.updateSteppers();
              }
              start = false;
            }
            if (_distanceSensors.detectEntrance(false, true)){
              // Front wall is detected
              // Task 1 is done
              start = true;
              step = 7;
              
              }else{
              // Front wall is not yet detected
              _wallFollow.followRightWall(10.0f);
              _wallFollow.updateSteppers();  
            }
        }else if (step == 7){
            delay(1000);
            Serial.println(5);
            delay(1000);
            
            irsensors.read();
            while (!tracker.detectJunction(irsensors.values)){
              _wallFollow.followRightWall(15.0f);
              _wallFollow.updateSteppers();
              irsensors.read();
            }
            _motors.runForward(100, 100);
            _motors.turnLeft90();
            task1finished = 1;
        }
    }

private:
    STEPPERcontroller& _motors;
    SharpIRArray& _distanceSensors;
    WallFollower& _wallFollow;
};

#endif