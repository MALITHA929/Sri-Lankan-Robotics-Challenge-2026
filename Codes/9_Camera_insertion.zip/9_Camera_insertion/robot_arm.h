#ifndef ROBOT_ARM_H
#define ROBOT_ARM_H

#include "stepper_motor.h"
#include "line_follower.h"
#include <Servo.h>

class RobotArm {
private:
    Servo baseServo;     // myServo_01
    Servo bigServo;      // myServo_02
    Servo smallServo;    // myServo_03
    Servo leftGripper;   // myServo_04
    Servo rightGripper;  // myServo_05

    int betweenDelay = 50; //50 set these values after testing
    int angledelay = 10; //10

    int baseMid = 100;       int baseRight = 5;         int baseLeft = 200;
    int bigUp = 95;        int bigDown = 10;           int bigBack = 110;
    int smallUp = 95;      int smallDown = 10;         int smallBack = 180;
    int leftOpen = 65;      int leftClose = 140;        int leftPerpend = 110;
    int rightOpen = 115;    int rightClose = 40;         int rightPerpend = 70;

public:
    // Initialize the servos and set them to their default starting positions
    void init(int pinBase, int pinBig, int pinSmall, int pinLeftGrip, int pinRightGrip) {
        baseServo.attach(pinBase);
        bigServo.attach(pinBig);
        smallServo.attach(pinSmall);
        leftGripper.attach(pinLeftGrip);
        rightGripper.attach(pinRightGrip);

        // initial positions 
        baseServo.write(baseMid);           // base (0-180)
        bigServo.write(bigUp);             // big servo - horizontal (90_up- 0_down)
        smallServo.write(smallUp);          // small servo - horizontal (45_down-145_up)
        leftGripper.write(65);          // gripper left (45_open-180_close)
        rightGripper.write(115);        // gripper right (0_close -135_open)
        
        delay(1000); // Give servos time to reach origin
    }
    void pickBox(STEPPERcontroller& motors,int picked_box_count){
        if(picked_box_count < 3){
            pickBoxright(motors,picked_box_count);
        }else if(picked_box_count == 3){
            pickBoxUp1(motors);
        }else if(picked_box_count == 4){
            pickBoxUp2(motors);
        }else{
            pickBoxUp3(motors);
        }
    }
    

    // Execute the full picking and placing sequence
    void pickBoxright(STEPPERcontroller& motors,int picked_box_count) { 
        
        delay(500);

        ////// big_servo-horizontal__ down ///////////////
        for (int pos = bigUp; pos >= bigDown; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        motors.runForward(100, 25);
        delay(betweenDelay);
        //////// grippers_close ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
            rightGripper.write(rightOpen - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// big_servo-horizontal__ up ///////////////
        for (int pos = bigDown; pos <= bigUp; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// base right ///////////////
        for (int pos = baseMid; pos >= baseRight; pos--) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ down ///////////////
        for (int pos = smallUp; pos >= smallDown; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 0; pos <= 30; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(rightClose + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 30; pos <= 70; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ up ///////////////
        for (int pos = smallDown; pos <= smallUp; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// base origin ///////////////
        for (int pos = baseRight; pos <= baseMid; pos++) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        if(!(picked_box_count ==2)){
        //////// small_servo-horizontal__ down ///////////////
            for (int pos = smallUp; pos >= smallDown; pos--) {
                smallServo.write(pos);
                delay(angledelay);
            }
            delay(betweenDelay);

            //////// base left ///////////////
            for (int pos = baseMid; pos >= baseRight; pos--) {
                baseServo.write(pos);
                delay(15);
            }
            delay(betweenDelay);

            //////// base origin ///////////////
            for (int pos = baseRight; pos <= baseMid; pos++) {
                baseServo.write(pos);
                delay(angledelay);
            }
            delay(betweenDelay);

            //////// small_servo-horizontal__ up ///////////////
            for (int pos = smallDown; pos <= smallUp; pos++) {
                smallServo.write(pos);
                delay(angledelay);
            }
            delay(betweenDelay);
        }
        //////// Right servo initial ///////////////
        for (int pos = 70; pos <= rightOpen; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// Left servo initial ///////////////
        for (int pos = 70; pos >= leftOpen; pos--) {
            leftGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Storer in upper container...
    void pickBoxUp1(STEPPERcontroller& motors){
        delay(500);

        ////// big_servo-horizontal__ down ///////////////
        for (int pos = bigUp; pos >= bigDown; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        motors.runForward(100, 25);
        delay(betweenDelay);

        //////// grippers_close ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
            rightGripper.write(rightOpen - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// big_servo-horizontal__ up ///////////////
        for (int pos = bigDown; pos <= bigUp; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo back/////////////////
        for (int pos = smallUp; pos <= smallBack; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo back///////////////////////
        for (int pos = bigUp; pos <= bigBack; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(rightClose + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo Up///////////////////////
        for (int pos = bigBack; pos >= bigUp; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo Up/////////////////
        for (int pos = smallBack; pos >= smallUp; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_close ///////////////
        for (int pos = 65; pos <= 170; pos++) {
            leftGripper.write(pos);
            delay(angledelay);
        }
        // delay(betweenDelay);
        // for (int pos = 115; pos <= 150; pos++) {
        //     rightFripper.write(pos);
        //     delay(angledelay);
        // }
        // delay(betweenDelay);

        ///////////////small servo back/////////////////
        for (int pos = smallUp; pos <= smallBack; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo back///////////////////////
        for (int pos = bigUp; pos <= bigBack; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 170; pos >= 65; pos--) {
            leftGripper.write(pos);
            delay(angledelay);
        }

        ///////// big_servo Up///////////////////////
        for (int pos = bigBack; pos >= bigUp; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo Up/////////////////
        for (int pos = smallBack; pos >= smallUp; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

    }

    void pickBoxUp2(STEPPERcontroller& motors){
        delay(500);

        ////// big_servo-horizontal__ down ///////////////
        for (int pos = bigUp; pos >= bigDown; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        motors.runForward(100, 25);
        delay(betweenDelay);

        //////// grippers_close ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
            rightGripper.write(rightOpen - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// big_servo-horizontal__ up ///////////////
        for (int pos = bigDown; pos <= bigUp; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo back/////////////////
        for (int pos = smallUp; pos <= smallBack; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo back///////////////////////
        for (int pos = bigUp; pos <= bigBack; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(rightClose + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 115; pos <= 160; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 65; pos <= 160; pos++) {
            leftGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo Up///////////////////////
        for (int pos = bigBack; pos >= bigUp; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo Up/////////////////
        for (int pos = smallBack; pos >= smallUp; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 160; pos >= 115; pos--) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 160; pos >= 65; pos--) {
            leftGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 115; pos >= 20; pos--) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo back/////////////////
        for (int pos = smallUp; pos <= smallBack; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo back///////////////////////
        for (int pos = bigUp; pos <= bigBack; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 20; pos <= 85; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo Up///////////////////////
        for (int pos = bigBack; pos >= bigUp; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo Up/////////////////
        for (int pos = smallBack; pos >= smallUp; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 85; pos <= 115; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

    }


    void pickBoxUp3(STEPPERcontroller& motors){
        delay(500);

        ////// big_servo-horizontal__ down ///////////////
        for (int pos = bigUp; pos >= bigDown; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        motors.runForward(100, 25);
        delay(betweenDelay);

        //////// grippers_close ///////////////
        for (int pos = 0; pos <= 75; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
            rightGripper.write(rightOpen - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// big_servo-horizontal__ up ///////////////
        for (int pos = bigDown; pos <= bigUp; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo back/////////////////
        for (int pos = smallUp; pos <= smallBack; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo back///////////////////////
        for (int pos = bigUp; pos <= bigBack; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 0; pos <= 40; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(rightClose + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////// big_servo Up///////////////////////
        for (int pos = bigBack; pos >= bigUp; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        ///////////////small servo Up/////////////////
        for (int pos = smallBack; pos >= smallUp; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 40; pos <= 75; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(rightClose + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

    }

    void armboxInsert(){
        for (int pos = 0; pos <= 135; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = rightOpen; pos >= 30; pos--) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = baseMid; pos >= baseRight; pos--) {
            baseServo.write(pos);
            delay(15);
        }
        delay(betweenDelay);

        for (int pos = bigUp; pos <= 120; pos++) {
            bigServo.write(pos);
            delay(15);
        }
        delay(betweenDelay);

        for (int pos = smallUp; pos >= smallDown-30; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 30; pos <= 90; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = baseRight; pos <= 100; pos++) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);
        for (int pos = smallDown-30; pos <= smallUp; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);
    }

    ///// No longer using this function /////////////////////
    void pickBoxleft(STEPPERcontroller& motors) { 
        delay(500);

        ////// big_servo-horizontal__ down ///////////////
        for (int pos = bigUp; pos >= bigDown; pos--) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        motors.runForward(100, 25);

        //////// grippers_close ///////////////
        for (int pos = 0; pos <= 135; pos++) {
            leftGripper.write(leftOpen + pos);
            delay(angledelay);
            rightGripper.write(rightOpen - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// big_servo-horizontal__ up ///////////////
        for (int pos = bigDown; pos <= bigUp; pos++) {
            bigServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// base right ///////////////
        for (int pos = baseMid; pos <= baseLeft; pos++) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ down ///////////////
        for (int pos = smallUp; pos >= smallDown; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// grippers_open ///////////////
        for (int pos = 0; pos <= 50; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        for (int pos = 50; pos <= 90; pos++) {
            leftGripper.write(leftClose - pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ up ///////////////
        for (int pos = smallDown; pos <= smallUp; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// base origin ///////////////
        for (int pos = baseLeft; pos >= baseMid; pos--) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ down ///////////////
        for (int pos = smallUp; pos >= smallDown; pos--) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        // //////// grippers_close ///////////////
        // for (int pos = 0; pos <= 45; pos++) {
        //     leftGripper.write(135 + pos);
        //     delay(15);
        //     rightGripper.write(45 - pos);
        //     delay(15);
        // }

        //////// base left ///////////////
        for (int pos = baseMid; pos <= baseLeft; pos++) {
            baseServo.write(pos);
            delay(15);
        }
        delay(betweenDelay);

        //////// base origin ///////////////
        for (int pos = baseLeft; pos >= baseMid; pos--) {
            baseServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// small_servo-horizontal__ up ///////////////
        for (int pos = smallDown; pos <= smallUp; pos++) {
            smallServo.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// Right servo initial ///////////////
        for (int pos = 50; pos <= rightOpen; pos++) {
            rightGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        //////// Left servo initial ///////////////
        for (int pos = 90; pos >= leftOpen; pos--) {
            leftGripper.write(pos);
            delay(angledelay);
        }
        delay(betweenDelay);

        // //////// grippers_open ///////////////
        // for (int pos = 0; pos <= 135; pos++) {
        //     leftGripper.write(180 - pos);
        //     delay(15);
        //     rightGripper.write(pos);
        //     delay(15);
        // }
    }
};

#endif