#ifndef ROBOT1_H
#define ROBOT1_H

class Robot1 {
private:
    // State variables specific to Strategy 1
    int firstWallDetected = 0;
    int secondWallDetected = 0;
    int detectedWallcount = 0;
    int taskMode = 0;          
    bool goOut = 0;
    int box_detected = 0;
    int picked_box_count = 0;
    bool isFinished = false; 
    bool foundline = 0;
    bool turnToTask3 = 0;
    bool start = true;
    int step = 1;
    bool task1finished =0;

public:
    void run(LINEtracker& tracker, PiCommunicator& Picom, STEPPERcontroller& motors, 
             BoxNavigator& navigator, LineFollower& lineFollow, SharpIRArray& distanceSensors, 
             BoxInsertNav& insert, RobotArm& arm, IRarray& irsensors, WallFollower& wallFollow, Task1& task1Nav) {

        /////////////////////////////////////////////////////////////////// TASK 1 ///////////////////////////////////////////////////////////////
        if(!task1Nav.task1finished){
            Serial.println(taskMode);
        }
        
        while(!task1Nav.task1finished){
            task1Nav.run(tracker, irsensors);
            if(task1Nav.task1finished){
                taskMode = 1;
            }
        }

        //////////////////////////////////////////////////////////////////// TASK 2 ///////////////////////////////////////////////////////////////////
        while (picked_box_count < 6 && !goOut) {
            Serial.println(taskMode);

            ///////////////////// Line Following //////////////////////
            while (taskMode == 1 && !goOut) {
                lineFollow.update(true);      
                lineFollow.updateSteppers();  
                Picom.update(); 

                distanceSensors.update();
                if (8 < (distanceSensors.getDistance(0)) && (distanceSensors.getDistance(0) < 12)) {
                    if(detectedWallcount == 1){
                        goOut = 1;
                    }
                    motors.runBackward(100, 120);
                    motors.turnRight90();
                    motors.turnRight90();
                    detectedWallcount++;
                }

                if (Picom.hasNewTrackingData()) {
                    if (navigator.trackBoxCenter(Picom.getBoxCenter())) {
                        Serial.println("Box Alignment Detected! Turning Left...");
                        lineFollow.stop();   
                        motors.turnLeft90(); 
                        box_detected = 1;
                        taskMode = 2; 
                        navigator.checkstop = 0; 
                        Serial.println(2);
                        delay(1000);
                    }
                    Picom.clearTrackingDataFlag();
                } 
            }
        
            ////////////////////// Box Following ///////////////////////////
            delay(1000);
            motors.runForward(100, 100);

            while (taskMode == 2 && !navigator.checkstop) {
                Picom.update(); 
                if (Picom.isStopRequested()) {
                    navigator.stop();
                    Picom.clearStopRequest();
                }
                else if (Picom.hasNewTrackingData()) {
                    navigator.followBoxCenter(Picom.getBoxCenter(), Picom.getBoxWidth()); 
                    Picom.clearTrackingDataFlag();
                }
                motors.runMotors();
            }

            ///////////////////// Box picking ///////////////////////////////////////
            if(taskMode == 2){
                arm.pickBox(motors, picked_box_count);
                picked_box_count++;

                motors.runBackward(100,150);
                taskMode = 3;
                Serial.println(taskMode);

                // NEW: SMART WAITING LOOP WITH 4-SECOND TIMEOUT
                unsigned long scanStartTime = millis();
                bool tagScanned = false;
                
                // Wait until we get "TAG_OK" OR 4000 milliseconds have passed
                while (millis() - scanStartTime < 4000) { 
                    if (Serial.available() > 0) {
                        String incomingMsg = Serial.readStringUntil('\n');
                        incomingMsg.trim(); // Remove invisible \r or \n characters
                        
                        if (incomingMsg == "TAG_OK") {
                            tagScanned = true;
                            break; // Exit the while loop immediately!
                        }
                    }
                }

                //////////////// come back to line ///////////////////////////////
                lineFollow.runBackwardUntilLine(100);
                motors.stop();
                delay(1000); 
                lineFollow.alignWithPerpendicularLine();

                /////////////// Turn right to line /////////////////////////////
                delay(200);
                motors.runForward(100, 100);
                
                if(picked_box_count == 6){
                    goOut = 1;
                    motors.turnLeft90();
                    motors.runForward(100, 200);
                }else{
                    motors.turnRight90();
                    motors.runForward(100, 350);
                }
                taskMode = 1;
                box_detected = 0;
                Serial.println(taskMode);
                delay(1000);
            }

        ////////////////////////////////////////////////////////////////////// TASK 3 /////////////////////////////////////////////////////////////////////  

            if(goOut){
                while(!turnToTask3){
                    lineFollow.update(true);      
                    lineFollow.updateSteppers();
                    distanceSensors.update();
                    if (8 < (distanceSensors.getDistance(0)) && (distanceSensors.getDistance(0) < 12)) {
                        motors.runBackward(100, 120);
                        motors.turnLeft90();
                        turnToTask3 = 1;
                    }
                }
        ///////////////////// sending the coordinates to simulation ///////////////////

                Serial.println(6); 
                delay(1000);
                Serial.println(4);

        /////////////////////////////////////////////////////////////////////////////
                lineFollow.alignWithPerpendicularLine();
                motors.runForward(100, 150);
                lineFollow.runForwardUntilLine(100);
                motors.runForward(100, 250);

                irsensors.read();
                while(!tracker.detectLeftJunction(irsensors.values)){
                    lineFollow.update(true);      
                    lineFollow.updateSteppers();
                    irsensors.read();
                }
                motors.runForward(100, 140);
                motors.turnLeft90();

        ////////////////////////// Turned left to laser particle ///////////////////////
                motors.runForward(100, 200);

                irsensors.read();
                while(!tracker.detectTJunc(irsensors.values)){
                    lineFollow.update(true);      
                    lineFollow.updateSteppers();
                    irsensors.read();
                }

                motors.runForward(100, 100);
                lineFollow.alignWithPerpendicularLine();

        /////////////////////////// At the T junction ////////////////////////////////
                motors.turnLeft90();
                motors.runForward(100, 145); 
                motors.turnRight90();
                
        ///////////////////////////////////////VISION LOOP/////////////////////////////
                Serial.println("Starting Vision-Guided Insertion...");
                Picom.clearTrackingDataFlag();
                navigator.checkstop = 0;

                while (!navigator.checkstop) {
                    Picom.update(); 
                    
                    if (Picom.isStopRequested()) {
                        navigator.stop();
                        Picom.clearStopRequest();
                    }
                    else if (Picom.hasNewTrackingData()) {
                        // Drive towards the tube using the front camera!
                        navigator.followInsertionTube(Picom.getBoxCenter(), Picom.getBoxWidth()); 
                        Picom.clearTrackingDataFlag();
                    }
                    motors.runMotors();
                }
                Serial.println("Tube Reached! Executing Arm Insertion.");

        ///////////////////////////////////END VISION LOOP/////////////////////////////////
                insert.run();
                arm.armboxInsert();

                int i=0;
                while(i==0){
                    motors.stop();
                }
                
            }
        }

    }
};

#endif