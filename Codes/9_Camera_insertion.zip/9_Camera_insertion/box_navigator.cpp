#include "box_navigator.h"

BoxNavigator::BoxNavigator(STEPPERcontroller& motorRef) : _motors(motorRef) {}

void BoxNavigator::init() {
    _pid.init();
    _pid.Kp = 0.7f;   
    _pid.Ki = 0.02f;  
    _pid.Kd = 0.05f;   
    _pid.T = 0.05f;   
    _pid.tau = 0.02f;
    _pid.limMin = -300.0f; 
    _pid.limMax = 300.0f;
    _pid.limMinInt = -50.0f;
    _pid.limMaxInt = 50.0f;
}

// 1. Check if side camera is aligned
bool BoxNavigator::trackBoxCenter(int boxCenter) {
    if (boxCenter >= _camCenterMin && boxCenter <= _camCenterMax) {
        return true;
    }
    return false;
}

// 2. Steer towards the box using front camera
void BoxNavigator::followBoxCenter(int boxCenter, int boxWidth) {
    // Stop if we are close enough
    if (boxWidth > _stopWidth) {
        _motors.stop();
        checkstop = 1;
    } 
    else {
        float error = 0;
        if (boxCenter > (_videoCenter + _deadzone)) {
            error = _videoCenter - boxCenter; 
        } else if (boxCenter < (_videoCenter - _deadzone)) {
            error = _videoCenter - boxCenter; 
        }

        // Use PID to calculate the steering adjustment
        float steer = _pid.update(0, -error);

        float leftSpeed = _baseSpeed - steer;
        float rightSpeed = _baseSpeed + steer;

        _motors.setSpeed(leftSpeed, rightSpeed);
    }
}

void BoxNavigator::followInsertionTube(int tubeCenter, int tubeWidth) {
    // Stop if we are close enough to the tube
    if (tubeWidth > _insertionStopWidth) {
        _motors.stop();
        checkstop = 1;
    } 
    else {
        float error = 0;
        // Check if center of tube is outside our defined deadzone range
        if (tubeCenter > (_videoCenter + _deadzone)) {
            error = _videoCenter - tubeCenter; 
        } else if (tubeCenter < (_videoCenter - _deadzone)) {
            error = _videoCenter - tubeCenter; 
        } else {
            error = 0; 
        }

        // Use PID to calculate the steering adjustment
        float steer = _pid.update(0, -error);

        float leftSpeed = _baseSpeed - steer;
        float rightSpeed = _baseSpeed + steer;

        _motors.setSpeed(leftSpeed, rightSpeed);
    }
}

void BoxNavigator::stop() {
    _motors.stop();
}