#ifndef ROBOT2_H
#define ROBOT2_H

class Robot2 {
private:
    // State variables specific to Strategy 1
    int firstWallDetected = 0;
    int secondWallDetected = 0;
    int detectedWallcount = 0;
    int taskMode = 0;          
    bool goOut = 0;
    int box_detected = 0;
    int picked_box_count = 0;
    bool isFinished = false; 
    bool foundline = 0;
    bool turnToTask3 = 0;
    bool start = true;
    int step = 1;
    bool task1finished =0;

public:
    void run(LINEtracker& tracker, PiCommunicator& Picom, STEPPERcontroller& motors, 
             BoxNavigator& navigator, LineFollower& lineFollow, SharpIRArray& distanceSensors, 
             BoxInsertNav& insert, RobotArm& arm, IRarray& irsensors, WallFollower& wallFollow, Task1& task1Nav) {

        Serial.println(4);           
        lineFollow.alignWithPerpendicularLine();
        motors.runForward(100, 150);

        irsensors.read();

        while (!tracker.detectJunction(irsensors.values)){
            wallFollow.followRightWall(15.0f);
            wallFollow.updateSteppers();
            irsensors.read();
        }

        motors.runForward(100, 150);

        irsensors.read();
        while(!tracker.detectLeftJunction(irsensors.values)){
            lineFollow.update(true);      
            lineFollow.updateSteppers();
            irsensors.read();
        }
        motors.runBackward(100, 100);
        motors.turnLeft90();

        Picom.clearTrackingDataFlag();
        navigator.checkstop = 0;

        while (!navigator.checkstop) {
            Picom.update(); 
            
            if (Picom.isStopRequested()) {
                navigator.stop();
                Picom.clearStopRequest();
            }
            else if (Picom.hasNewTrackingData()) {
                // Drive towards the tube using the front camera!
                navigator.followInsertionTube(Picom.getBoxCenter(), Picom.getBoxWidth()); 
                Picom.clearTrackingDataFlag();
            }
            motors.runMotors();
        }

        motors.runForward(100, 200);

        int i=0;
        while(i==0){
            motors.stop();
        }
    }
};

#endif