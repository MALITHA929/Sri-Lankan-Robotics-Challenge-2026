#include "pi_communicator.h"

PiCommunicator::PiCommunicator() {
    _buffer = "";
    _newTrackingData = false;
    _stopRequested = false;
    _boxCenter = 0;
    _boxWidth = 0;
    _buffer.reserve(50); 
}

void PiCommunicator::update() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        if (c == '\n') {
            processMessage(_buffer);
            _buffer = ""; 
        } else {
            _buffer += c;
        }
    }
}

void PiCommunicator::processMessage(String msg) {
    if (msg.startsWith("C1:")) {
        int x, y, w, h;
        // Parse the string and calculate the center instantly
        if (sscanf(msg.c_str(), "C1:%d,%d,%d,%d", &x, &y, &w, &h) == 4) {
            _boxCenter = x + (w / 2);
            _boxWidth = w;
            _newTrackingData = true; // Flag that we have fresh numbers
        }
    } 
    else if (msg == "STOP" || msg == "SEARCH") {
        _stopRequested = true;
        _newTrackingData = false;
    }
}

// Getters
bool PiCommunicator::hasNewTrackingData() { return _newTrackingData; }
bool PiCommunicator::isStopRequested() { return _stopRequested; }
int PiCommunicator::getBoxCenter() { return _boxCenter; }
int PiCommunicator::getBoxWidth() { return _boxWidth; }

// Clearers
void PiCommunicator::clearTrackingDataFlag() { _newTrackingData = false; }
void PiCommunicator::clearStopRequest() { _stopRequested = false; }