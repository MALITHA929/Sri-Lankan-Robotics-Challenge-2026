#ifndef IR_ARRAY_H
#define IR_ARRAY_H

#include <Arduino.h>

// Number of sensors in the array
#define NUM_SENSORS 8

class IRarray {
public:
    bool values[NUM_SENSORS];   // stores sensor readings (0 or 1)

    // Constructor
    IRarray();

    // Initialize sensor pins
    void init();

    // Read all sensors
    void read();

    // Print sensor values to Serial Monitor
    void print();

private:
    int sensorPins[NUM_SENSORS];   // internal pin list
};

#endif