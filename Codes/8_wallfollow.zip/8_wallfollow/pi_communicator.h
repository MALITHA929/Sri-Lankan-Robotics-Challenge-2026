#ifndef PI_COMMUNICATOR_H
#define PI_COMMUNICATOR_H

#include <Arduino.h>

class PiCommunicator {
public:
    PiCommunicator();

    void update(); 

    // --- State Checkers ---
    bool hasNewTrackingData();
    bool isStopRequested();
    
    // --- Data Retrieval ---
    int getBoxCenter();
    int getBoxWidth();

    // --- State Clearers ---
    void clearTrackingDataFlag();
    void clearStopRequest();

private:
    String _buffer;
    
    bool _newTrackingData;
    bool _stopRequested;

    // Store the calculated integers
    int _boxCenter;
    int _boxWidth;

    void processMessage(String msg);
};

#endif