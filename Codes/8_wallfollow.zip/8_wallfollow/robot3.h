#ifndef ROBOT3_H
#define ROBOT3_H

class Robot3 {
private:
    // State variables specific to Strategy 1
    int firstWallDetected = 0;
    int secondWallDetected = 0;
    int taskMode = 1;                
    int box_detected = 0;
    int passed_box_count = 0;
    int picked_box_count = 0;
    bool isFinished = false; // Prevents the loop from restarting once all 6 boxes are done

public:
    // We pass all the hardware objects into the run function so it can control them
    void run(LINEtracker& tracker, PiCommunicator& Picom, STEPPERcontroller& motors, 
             BoxNavigator& navigator, LineFollower& lineFollow, SharpIRArray& distanceSensors, 
             BoxInsertNav& insert, RobotArm& arm, IRarray& irsensors, WallFollower& wallFollow) {

        insert.sliderback();   // 0 - move to back
        //arm.pickBox(motors, 1);
        ////////////////////////////////////////////////////////////////////// FINAL INSERTION ///////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////     Task 3      //////////////////////////////////////////////////////////////////////////////////////

       
    }
};

#endif