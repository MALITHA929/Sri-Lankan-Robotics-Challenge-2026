#ifndef BOX_NAVIGATOR_H
#define BOX_NAVIGATOR_H

#include <Arduino.h>
#include "PID.h"
#include "stepper_motor.h"

class BoxNavigator {
public:
    bool checkstop = 0;
    BoxNavigator(STEPPERcontroller& motorRef);
    void init();
    
    // The two new functions you requested
    bool trackBoxCenter(int boxCenter);
    void followBoxCenter(int boxCenter, int boxWidth);
    
    void stop();

private:
    STEPPERcontroller& _motors;
    PIDController _pid;
    
    const int _videoCenter = 320;   
    const int _deadzone = 20;       
    const float _baseSpeed = 100.0f; 
    const int _stopWidth = 400; 

    // Alignment thresholds for the side camera
    const int _camCenterMin = 360; 
    const int _camCenterMax = 380; 
};

#endif