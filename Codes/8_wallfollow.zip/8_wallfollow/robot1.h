#ifndef ROBOT1_H
#define ROBOT1_H

class Robot1 {
private:
    // State variables specific to Strategy 1
    int firstWallDetected = 0;
    int secondWallDetected = 0;
    int taskMode = 1;                
    int box_detected = 0;
    int picked_box_count = 0;
    int passed_box_count = 0;
    bool isFinished = false; // Prevents the loop from restarting once all 6 boxes are done
    bool foundline = 0;

public:
    void run(LINEtracker& tracker, PiCommunicator& Picom, STEPPERcontroller& motors, 
             BoxNavigator& navigator, LineFollower& lineFollow, SharpIRArray& distanceSensors, 
             BoxInsertNav& insert, RobotArm& arm, IRarray& irsensors, WallFollower& wallFollow) {
            
            delay(2000);
            motors.runForward(100, 1200);
            Serial.println("asdadfasdfasd");
            lineFollow.runForwardUntilLine(100);
            motors.runForward(100, 140);
            motors.turnLeft90();
            foundline = 1;
        

        while (passed_box_count < 4) {
            Serial.println(taskMode);
            /////////////////////// Task 1: Line Following //////////////////////////
            while (taskMode == 1 && !secondWallDetected) {
                lineFollow.update(true);      
                lineFollow.updateSteppers();  
                Picom.update(); 

                distanceSensors.update();
                if (10 < (distanceSensors.getDistance(0)) && (distanceSensors.getDistance(0) < 16)) {
                    motors.runBackward(100, 80);
                    motors.turnLeft90();
                    firstWallDetected = 1;
                    passed_box_count = 3;
                    secondWallDetected = 1;
                }

                if (Picom.hasNewTrackingData()) {
                    if (navigator.trackBoxCenter(Picom.getBoxCenter())) {
                        Serial.println("Box Alignment Detected! Turning Left...");
                        lineFollow.stop();   
                        motors.turnLeft90(); 
                        box_detected = 1;
                        taskMode = 2; 
                        passed_box_count++;
                        navigator.checkstop = 0; 
                        Serial.println(2);
                        delay(1000);
                    }
                    Picom.clearTrackingDataFlag();
                } 
            }
        
            ////////////////////// Task 2: Box Following ///////////////////////////
            delay(1000);
            motors.runForward(100, 100);

            while (taskMode == 2 && !navigator.checkstop && !secondWallDetected) {
                Picom.update(); 
                if (Picom.isStopRequested()) {
                    navigator.stop();
                    Picom.clearStopRequest();
                }
                else if (Picom.hasNewTrackingData()) {
                    navigator.followBoxCenter(Picom.getBoxCenter(), Picom.getBoxWidth()); 
                    Picom.clearTrackingDataFlag();
                }
                motors.runMotors();
            }

            /////////////////////Box picking///////////////////////////////////////
            if(taskMode ==2){
                arm.pickBox(motors, picked_box_count);
                picked_box_count++;
                //////////////// come back to line///////////////////////////////////
                lineFollow.runBackwardUntilLine(100);
                motors.stop();
                delay(1000); 
                lineFollow.alignWithPerpendicularLine();

                ///////////////////Turn right to line/////////////////////////////////
                delay(200);
                motors.runForward(100, 100);
                motors.turnRight90();
                motors.runForward(100, 300);
                taskMode = 1;
                box_detected = 0;
                Serial.println(taskMode);
                delay(1000);
            }

//////////////////////////////////////////////////////////////////////Turn to task 3/////////////////////////////////////////////////////////////////////

            if(passed_box_count > 3 || secondWallDetected){
                
                if(!secondWallDetected){
                    lineFollow.update(true);      
                    lineFollow.updateSteppers();  
                    distanceSensors.update();
                    Serial.println(distanceSensors.getDistance(0));

                    if (10 < (distanceSensors.getDistance(0)) && (distanceSensors.getDistance(0) < 16)){
                        motors.runBackward(100, 80);
                        motors.turnLeft90();
                        lineFollow.alignWithPerpendicularLine();
                        secondWallDetected = 1;
                    }
                }else {
                    
                    motors.runForward(100, 150);
                    motors.runForward(100, 200);

                    irsensors.read();
                    while(!tracker.detectLeftJunction(irsensors.values)){
                        lineFollow.update(true);      
                        lineFollow.updateSteppers();
                        irsensors.read();
                    }
                    motors.runForward(100, 140);
                    motors.turnLeft90();
    ///////////////////////////////////////////////////////////Turned left to laser particle/////////////////////////////////////////////////////////////
                    motors.runForward(100, 200);

                    irsensors.read();
                    while(!tracker.detectTJunc(irsensors.values)){
                        lineFollow.update(true);      
                        lineFollow.updateSteppers();
                        irsensors.read();
                    }

                    motors.runForward(100, 100);
                    lineFollow.alignWithPerpendicularLine();

                    motors.turnLeft90();
                    motors.runForward(100, 145); // TUNE: Alignment steps
                    motors.turnRight90();
                    motors.runForward(100, 349);
                    //motors.setSpeed(100, 100); 
                    // distanceSensors.update();
                    // while (distanceSensors.getDistance(0) > 8) { 
                    //     motors.runMotors();
                    //     distanceSensors.update(); 
                    // }

                    insert.run();
                    arm.armboxInsert();

                    int i=0;
                        while(i==0){
                        motors.stop();
                    }
                }
            }
        }

    }
};

#endif