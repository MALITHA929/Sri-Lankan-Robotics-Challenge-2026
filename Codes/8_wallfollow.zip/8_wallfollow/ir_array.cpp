#include "ir_array.h"

// Constructor
IRarray::IRarray() {

    // Assign sensor pins
    sensorPins[0] = 43;
    sensorPins[1] = 41;
    sensorPins[2] = 39;
    sensorPins[3] = 37;
    sensorPins[4] = 35;
    sensorPins[5] = 33;
    sensorPins[6] = 31;
    sensorPins[7] = 29;
}

// Initialize sensor pins
void IRarray::init() {

    for (int i = 0; i < NUM_SENSORS; i++) {
        pinMode(sensorPins[i], INPUT);
    }
}

// Read sensor values
void IRarray::read() {

    for (int i = 0; i < NUM_SENSORS; i++) {
        values[i] = digitalRead(sensorPins[i]);
    }
}

// Print sensor values for debugging
void IRarray::print() {

    for (int i = 0; i < NUM_SENSORS; i++) {
        //Serial.print(values[i]);
        //Serial.print(" ");
    }

    Serial.println();
}