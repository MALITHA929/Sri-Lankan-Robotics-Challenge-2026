#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include <Arduino.h>
#include "PID.h"
#include "ir_array.h"
#include "line_tracker.h"
#include "stepper_motor.h"

class LineFollower {
public:
    // Update: This must match the prototype in your .cpp file
    LineFollower(STEPPERcontroller& motorRef);

    void init();     
    void update(bool followDir);   
    void updateSteppers();
    
    // Update: Add this declaration so the compiler knows about the stop function
    void stop(); 
    
    void runBackwardUntilLine(float speed);

    void runForwardUntilLine(float speed);

    void alignWithPerpendicularLine();

    void followUntilLeftJunction();
private:
    PIDController pid;
    IRarray irsensors;
    LINEtracker tracker;
    
    // Update: This MUST be a reference (&) to share the motor object
    STEPPERcontroller& steppers; 

    float baseSpeed;
    float steering;
    unsigned long lastTime;
    const unsigned long LOOP_INTERVAL_MS = 5;
    const float LOOP_DT = 0.005f;   

    void handleLineLost();
    void clampMotorSpeeds(float& left, float& right);
};

#endif