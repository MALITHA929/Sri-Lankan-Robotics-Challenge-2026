#include "line_follower.h"

// Initialize with the shared motor reference
LineFollower::LineFollower(STEPPERcontroller& motorRef) : steppers(motorRef) 
{
    baseSpeed = 105;
    steering  = 0;
    lastTime  = 0;
}

void LineFollower::init()
{
    irsensors.init();
    tracker.init();
    // steppers.init() is now called in main.ino to avoid double-initialization

    pid.Kp = 55.5f;
    pid.Ki = 0.0f;
    pid.Kd = 0.0f;
    pid.tau = 0.02f;
    pid.limMax = 200;
    pid.limMin = -200;
    pid.limMaxInt = 50;
    pid.limMinInt = -50;
    pid.T = LOOP_DT;
    pid.init();

    lastTime = millis();
}

void LineFollower::stop() {
    steppers.stop();
}

void LineFollower::update(bool followDir) {
    // 1. Use pure integer math for the timer
    if (millis() - lastTime < LOOP_INTERVAL_MS) return;
    lastTime = millis();

    irsensors.read();
    float pos = tracker.computePosition(irsensors.values);

    if (pos == 999.0f) {
        handleLineLost();
        return;
    }

    float setpoint = 0.0f;        
    steering = pid.update(setpoint, pos);

    float left  = baseSpeed + steering;
    float right = baseSpeed - steering;

    clampMotorSpeeds(left, right);

    if (followDir) {
        steppers.setSpeed(right, left);
    } else {
        steppers.setSpeed(-right, -left);
    }
}

void LineFollower::updateSteppers() {
    steppers.runMotors(); //
}

void LineFollower::handleLineLost() {
    // Simple logic: stop if line is lost
    steppers.stop();
}

void LineFollower::clampMotorSpeeds(float& left, float& right) {
    // Ensure speeds stay within NEMA 17 limits
    if (left > 1000)  left = 1000;
    if (left < -1000) left = -1000;
    if (right > 1000)  right = 1000;
    if (right < -1000) right = -1000;
}


void LineFollower::runBackwardUntilLine(float speed) {
    // 1. Set speeds (You may need to swap which one is negative based on your wiring)
    steppers.setSpeed(-speed, -speed); 
    
    // 2. Take an initial reading
    irsensors.read();
    
    // 3. Loop until the junction is detected
    while (!tracker.detectJunction(irsensors.values)) { 
        steppers.runMotors(); 
        irsensors.read(); // CRITICAL: Update sensor values while moving!
    }

    // 4. Stop immediately once the line is hit
    steppers.stop();
}

void LineFollower::runForwardUntilLine(float speed) {
    // 1. Set speeds (You may need to swap which one is negative based on your wiring)
    steppers.setSpeed(speed, speed); 
    
    // 2. Take an initial reading
    irsensors.read();
    
    // 3. Loop until the junction is detected
    while (!tracker.detectJunction(irsensors.values)) { 
        steppers.runMotors(); 
        irsensors.read(); // CRITICAL: Update sensor values while moving!
    }

    // 4. Stop immediately once the line is hit
    steppers.stop();
}

void LineFollower::alignWithPerpendicularLine() {
    float pos;
    bool detectPerpendicularLine;
    int count = 0;
    int speed = 60;
    int perpendicularCount = 0;

    while (true) {
        irsensors.read();
        pos = tracker.computePosition(irsensors.values);
        detectPerpendicularLine = tracker.isPerpendicularLine(irsensors.values);

        // Line is completely lost => Go back
        if (pos == 999.0f) {
            steppers.setSpeed(-speed, -speed); // Changed motors to steppers
            steppers.runMotors();
            delay(20);
            continue;
        }
        // If the perpendicular line is still available, take small steps
        if (detectPerpendicularLine) {
            steppers.setSpeed(speed, speed);
            steppers.runMotors();
            delay(20);
            perpendicularCount++;

            if(perpendicularCount >= 2){
                count == 50;
            }
            continue;
        }

        // Left side of the robot cross the line first => turn right
        if (irsensors.values[0] == 1 ) {
            steppers.setSpeed(-speed, speed);
        } 
        // Right side of the robot cross the line first => turn left
        else if (irsensors.values[7] == 1) {
            steppers.setSpeed(speed, -speed);
        }

        steppers.runMotors();
        delay(100);
        count++;

        // Stop condition (stable center)
        if (abs(pos) < 0.5 && count > 20) {
            steppers.stop();
            delay(1000); // Reduced from 5000 to prevent long freezes
            return;
        }
        // Exceeds the maximum number of turns
        if (count > 50) return;
    }
}