#ifndef SHARP_IR_ARRAY_H
#define SHARP_IR_ARRAY_H

#include <Arduino.h>

// Set this to the maximum number of Sharp sensors you plan to use
#define MAX_SHARP_SENSORS 5 // to change 

class SharpIRArray {
public:
    // Pass an array of analog pins, and how many there are
    SharpIRArray(const int pins[], int count);

    void init();

    // Call this rapidly in the main loop to keep the filter updated
    void update(); 

    // Get the smoothed distance in cm for a specific sensor (0 to count-1)
    float getDistance(int index); 

private:
    int _pins[MAX_SHARP_SENSORS];
    int _count;
    
    // Stores the smoothed voltage for each sensor
    float _smoothedVoltage[MAX_SHARP_SENSORS]; 
    
    // EMA smoothing factor (0.0 to 1.0). 
    // Lower = smoother but slower to react. 0.2 is a good balance.
    const float _alpha = 0.2f; 
};

#endif