#ifndef DIP_SWITCH_H
#define DIP_SWITCH_H

#include <Arduino.h>

class DipSwitch {
private:
    int pin1;
    int pin2;
    int pin3;

public:
    // Pass the three digital pins you connected the DIP switches to
    void init(int p1, int p2, int p3) {
        pin1 = p1;
        pin2 = p2;
        pin3 = p3;
        
        // INPUT_PULLUP means the pins sit at 5V (HIGH) normally.
        // When you flip the switch, it connects to Ground (LOW).
        pinMode(pin1, INPUT_PULLUP);
        pinMode(pin2, INPUT_PULLUP);
        pinMode(pin3, INPUT_PULLUP);
    }

    // Returns a mode from 1 to 3 based on which switch is flipped
    int readMode() {
        // We check which pin is pulled to Ground (LOW)
        if (digitalRead(pin1) == LOW) {
            return 1; // Strategy 1
        }
        else if (digitalRead(pin2) == LOW) {
            return 2; // Strategy 2
        }
        else if (digitalRead(pin3) == LOW) {
            return 3; // Strategy 3
        }
        
        // Fallback: If absolutely no switches are ON, return 0 (Standby)
        return 0; 
    }
};

#endif