#ifndef BOX_INSERT_NAV_H
#define BOX_INSERT_NAV_H

#include "line_follower.h"
#include "stepper_motor.h"
#include "sharp_ir_array.h"
#include "ir_array.h"
#include "line_tracker.h"
#include <Servo.h>

class BoxInsertNav {
private:
    Servo actuator;

public:

    void init(int servoPin) {
        actuator.attach(servoPin);
        actuator.write(90); 
    }

    void run() {

        actuator.write(180); // 180 - move to front (insert side)
        delay(25000);       
        actuator.write(0);   // 0 - move to back
        delay(14000);       
        actuator.write(90); 
    }
    void run1() {

        actuator.write(180); // 180 - move to front (insert side)
        delay(25000);       
        actuator.write(0);   // 0 - move to back
        delay(14000);       
        actuator.write(90); 
    }

    void sliderback(){
        actuator.write(0);
        delay(1000);
    }
    void stop(){
        actuator.write(90);
    }
    
};

#endif