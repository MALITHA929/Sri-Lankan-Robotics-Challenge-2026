#include "PID_wallfollower.h"

PIDwallfollow::PIDwallfollow():
    Kp(30.0f), Ki(0.0f), Kd(10.0f),
    outputMin(-200.0f), outputMax(200.0f),     // Change later
    prevError(0.0f),
    integral(0.0f),
    derivative(0.0f),
    prevMeasurement(0.0f),
    alpha(0.7f)   // smoothing (0 = no filter, 1 = heavy filter)
{}


void PIDwallfollow::reset(){
    prevError = 0.0f;
    integral = 0.0f;
    derivative = 0.0f;
    prevMeasurement = 0.0f;
}



float PIDwallfollow::compute(float setpoint, float measurement, float dt){

    float error = setpoint - measurement;

    // Proportional
    float P = Kp * error;

    // Integral (trapezoidal)
    integral += 0.5f * (error + prevError) * dt;
    float I = Ki * integral;

    // Derivative (on measurement, less noise sensitive)
    float rawDerivative = (measurement - prevMeasurement) / dt;

    // Low-pass filter
    derivative = alpha * derivative + (1 - alpha) * rawDerivative;

    float D = -Kd * derivative;

    // Output 
    float output = P + I + D;

    // Clamp output
    if (output > outputMax) {
        output = outputMax;
        // Anti-windup
        integral -= 0.5f * (error + prevError) * dt;
    }
    else if (output < outputMin) {
        output = outputMin;
        integral -= 0.5f * (error + prevError) * dt;
    }

    // Store values 
    prevError = error;
    prevMeasurement = measurement;

    return output;
}