#ifndef SINGLE_WALL_TRACKER_H
#define SINGLE_WALL_TRACKER_H

#include <Arduino.h>

class SINGLEWALLtracker{
  public:
    SINGLEWALLtracker();

    float computeError(float frontDist, float backDist);

    float getDistance(float frontDist, float backDist);   // Return the average distance to the wall
    float getAngle(float frontDist, float backDist);      // Return the angle error between robot and the wall


  private:
    float desiredDistance;   // target distance from wall
    float Kd;                // distance weight
    float Ka;                // angle weight
    float sensorSpacing;     // Distance between the 2 sensors
};



#endif