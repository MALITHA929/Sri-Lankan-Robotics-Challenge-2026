#ifndef PID_WALLFOLLOWER_H
#define PID_WALLFOLLOWER_H

class PIDwallfollow {

  public:
    PIDwallfollow();

    void reset();

    float compute(float setpoint, float measurement, float dt);


  private:
    float Kp, Ki, Kd;

    float prevError;
    float integral;
    float derivative;

    float outputMin, outputMax;

    float prevMeasurement;   // for derivative on measurement
    float alpha;             // derivative filter coefficient


};



#endif