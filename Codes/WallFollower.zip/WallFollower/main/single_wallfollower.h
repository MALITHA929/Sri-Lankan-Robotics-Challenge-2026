#ifndef SINGLE_WALLFOLLOWER
#define SINGLE_WALLFOLLOWER

#include "single_wall_tracker.h"
#include "PID_wallfollower.h"
#include "sharp_ir_array.h"
#include "stepper_motor.h"

const int sharpPins[] = {A10, A9};

class SINGLEWallFollower {

  public:
    SINGLEWallFollower();

    void init();
    void update();
  
  private:
    SINGLEWALLtracker walltracker;
    PIDwallfollow pid;
    SharpIRArray sensors = SharpIRArray(sharpPins, 2);
    STEPPERcontroller steppers;

    float baseSpeed;

    unsigned long lastTime;
    float loopDt;   // seconds

    void clampMotorSpeeds(float& left, float& right);


};


#endif