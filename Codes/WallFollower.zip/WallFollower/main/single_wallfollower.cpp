#include "single_wallfollower.h"

SINGLEWallFollower::SINGLEWallFollower(){
    baseSpeed = 100;
    loopDt = 0.01f;   // 10 ms
}


void SINGLEWallFollower::init() {
    //////// Init hardware
    sensors.init();
    steppers.init();

    
    pid.reset();
    lastTime = millis();
}


void SINGLEWallFollower::update() {

    // Maintain fixed loop timing
    unsigned long now = millis();
    float dt = (now - lastTime) / 1000.0f;

    if (dt < loopDt) return;

    lastTime = now;

    //Read sensors
    sensors.update();

    float front = sensors.getDistance(0);
    float back  = sensors.getDistance(1);

    // Compute wall error
    float error = walltracker.computeError(front, back);

    // PID output (steering)
    float steering = pid.compute(0.0f, error, dt);

    // Convert to motor speeds 
    float left  = baseSpeed + steering;
    float right = baseSpeed - steering;

    // Clamp speeds
    clampMotorSpeeds(left, right);

    // Apply speeds 
    steppers.setSpeed(left, right);
    steppers.runMotors();
}



// Clamp values to motor limits
void SINGLEWallFollower::clampMotorSpeeds(float& left, float& right)
{
    if (left > 255)  left = 255;
    if (left < -255) left = -255;
    if (right > 255)  right = 255;
    if (right < -255) right = -255;
}
