#include "single_wall_tracker.h"

SINGLEWALLtracker::SINGLEWALLtracker(): 
    desiredDistance(10.0f), Kd(1.0f), Ka(1.5f),
    sensorSpacing(11.5f)
{}

float SINGLEWALLtracker::getDistance(float front, float back) {
    return (front + back) / 2.0f;
}

float SINGLEWALLtracker::getAngle(float front, float back) {
    return (front - back) / sensorSpacing;
}

float SINGLEWALLtracker::computeError(float front, float back) {

    float distance = getDistance(front, back);
    float angle = getAngle(front, back);

    float error_dist = desiredDistance - distance;
    float error_angle = angle;

    return Kd * error_dist + Ka * error_angle;
}