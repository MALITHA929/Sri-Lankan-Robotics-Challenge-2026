#include "single_wallfollower.h"

// Line follow object
SINGLEWallFollower wallFollow;


void setup() {
  Serial.begin(115200);

  wallFollow.init();

}

void loop() {
  Serial.println("Running...");
  wallFollow.update();

}
