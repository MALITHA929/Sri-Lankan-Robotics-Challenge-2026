#include "stepper_motor.h"
#include "line_tracker.h"
#include "ir_array.h"

// Create objects
STEPPERcontroller steppers;
IRarray irsensors;
LINEtracker tracker;


void setup() {
  Serial.begin(115200);

  steppers.init();
  tracker.init();
  irsensors.init();


  alignWithPerpendicularLine();
}

void loop() {
  // put your main code here, to run repeatedly:

  while(true){delay(100);}

}



void alignWithPerpendicularLine() {
    float pos;
    bool detectPerpendicularLine;
    int count = 0;
    int speed = 60;

    while (true) {
        irsensors.read();
        pos = tracker.computePosition(irsensors.values);
        detectPerpendicularLine = tracker.isPerpendicularLine(irsensors.values);

       // Line is completely lost => Go back
        if (pos == 999.0f) {
            steppers.setSpeed(-speed, -speed);
            steppers.runMotors();
            delay(5);
            continue;
        }

        // If the perpendicular line is still available, take small steps
        if (detectPerpendicularLine) {
            steppers.setSpeed(speed, speed);
            steppers.runMotors();
            delay(5);
            continue;
        }

        // Left side of the robot cross the line first => turn right
        if (irsensors.values[0] == 1) {
            // left exited first → turn right
            steppers.setSpeed(-speed, speed);
        } 

        // Right side of the robot cross the line first => turn left
        else if (irsensors.values[7] == 1) {
            steppers.setSpeed(speed, -speed);
        }

        steppers.runMotors();
        delay(20);
        count++;

        // Stop condition (stable center)
        if (abs(pos) < 0.5 && count > 10) {
            steppers.stop();
            return;
        }

        // Exceeds the maximum number of turns
        if (count > 50) return;                /// Change as desired
    }
}

