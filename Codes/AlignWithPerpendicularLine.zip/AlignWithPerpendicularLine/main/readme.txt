// Set the pins correctly
// Check whether the steppers.stop() function is working properly.
// Change the speed as desired
// Change the maximum number of turns taken as desired (maximum limit for count variable (Last if condition in the function;  count > 50 => return;)

