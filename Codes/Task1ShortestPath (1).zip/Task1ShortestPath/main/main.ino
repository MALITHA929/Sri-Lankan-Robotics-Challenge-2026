#include "wall_follower.h"
#include "sharp_ir_array.h"
#include "stepper_motor.h"

const int sharpPins[] = {A8, A9, A10, A11, A12};


SharpIRArray distanceSensors(sharpPins, 5);
STEPPERcontroller motors;

WallFollower wallFollow(motors, distanceSensors);

// Parametes for navigation
bool start = true;
int step = 1;


void setup() {
  Serial.begin(115200);

  motors.init();
  distanceSensors.init(); 
  wallFollow.init();

}

void loop() {
  if (step == 1){
    
    // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

    // Follow the right wall until the gate is detected
    if (distanceSensors.detectEntrance(false, true) && distanceSensors.detectEntrance(false, false)){

      // Gate is detected
      delay(100);

      motors.runForward(100, 130);
      delay(100);
      // motors.turnRight180();
      motors.turnLeft90();
      delay(100);

      // Go to next step
      start = true;
      step = 2;
      delay(100);
      
    }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(16.5f);
      wallFollow.updateSteppers();  
    }
    

  }else if (step == 2){
      // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

    if (distanceSensors.getDistance(3) < 20.0f){
      // delay(100);
      // motors.runForward(100, 100);
      // delay(100);
      // motors.turnRight90();
      // delay(100);

      while (!distanceSensors.detectFrontWall()){
          wallFollow.followLeftWall(14.0f);
      wallFollow.updateSteppers();  
      }

       motors.turnRight90();
      delay(100);

      step = 3;
      start = true;
    }else{
      motors.setSpeed(100, 100);
      motors.runMotors();
      delay(5);

      distanceSensors.update();
    }


  }else if (step == 3){
       // Initial distance sensor reading
    if (start) {
      distanceSensors.update();

      while (!(distanceSensors.getDistance(1) < 20.0f)){
        motors.setSpeed(100, 100);
        motors.runMotors();

        delay(5);
        distanceSensors.update();

      }
      start = false;
    }

    if (distanceSensors.detectFrontWall()){
        motors.runBackward(100, 100);
        delay(100);
        motors.turnLeft90();
        delay(100);

        step = 4;
        start = true;

    }else{
       wallFollow.followRightWall(16.0f);    // 15
      wallFollow.updateSteppers(); 
    }


  }else if (step == 4){
        // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

      if (distanceSensors.detectEntrance(true, true)){
        motors.runForward(100, 250);
        delay(100);
        motors.turnRight90();
        delay(100);

        step = 5;
        start = true;

    }else{
       wallFollow.followRightWall(14.0f);
      wallFollow.updateSteppers(); 
    }


  }else if (step == 5){
          // Initial distance sensor reading
      if (start) {
        distanceSensors.update();

        while ((distanceSensors.getDistance(1) >= 30.0f) || (distanceSensors.getDistance(2) >= 30.0f)){
           // Front wall is not yet detected
          wallFollow.followLeftWall(10.0f);
          wallFollow.updateSteppers(); 
        }

        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(true, true)){

      // Front wall is detected
      delay(100);

      motors.runForward(100, 300);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 6;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 6){

         // Initial distance sensor reading
      if (start) {
        // motors.runForward(100, 200);
        distanceSensors.update();

        while (distanceSensors.getDistance(3) >= 30.0f){
          wallFollow.followRightWall(10.0f);
      wallFollow.updateSteppers();

        }
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Front wall is detected
      // Task 1 is done
      start = true;
      step = 7;
      
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }

}
