#include "wall_follower.h"

WallFollower::WallFollower(STEPPERcontroller& motorRef, SharpIRArray& irArrayRef) 
    : steppers(motorRef), distanceSensors(irArrayRef) 
{
    baseSpeed = 100; // Matches your line follower base speed
    lastTime = 0;
}

void WallFollower::init() {
    wallPid.Kp = 6.50f;  // Tune this if it oscillates
    wallPid.Ki = 0.0f;
    wallPid.Kd = 0.0f;
    wallPid.tau = 0.02f;
    wallPid.limMax = 100;
    wallPid.limMin = -100;
    wallPid.limMaxInt = 50;
    wallPid.limMinInt = -50;
    wallPid.T = LOOP_DT;
    wallPid.init();

    lastTime = millis();
}

void WallFollower::followRightWall(float targetDistance) {
    if (millis() - lastTime < LOOP_INTERVAL_MS) return;
    lastTime = millis();

    distanceSensors.update();

    // Assuming Sensor 0 is FRONT, Sensor 1 is BACK
    float frontDist = distanceSensors.getDistance(1);
    float backDist  = distanceSensors.getDistance(2);

    Serial.println(frontDist);
    Serial.println(backDist);

    // Safety: If wall is completely lost, just drive straight
    if (frontDist >= 29.0f && backDist >= 29.0f) {
        steppers.setSpeed(baseSpeed, baseSpeed);
        return;
    }

    float currentDistance = (frontDist + backDist) / 2.0f;
    float angleDiff = frontDist - backDist; 
    
    // TUNE THIS: Higher value forces the robot to stay perfectly parallel
    float angleWeight = 3.0f; 

    // Trick PID to steer right if pointing away from the wall
    float fusedMeasurement = currentDistance - (angleDiff * angleWeight);

    float steering = wallPid.update(targetDistance, fusedMeasurement);

    float leftMotorSpeed  = baseSpeed + steering;
    float rightMotorSpeed = baseSpeed - steering;

    clampMotorSpeeds(leftMotorSpeed, rightMotorSpeed);
    steppers.setSpeed(rightMotorSpeed, leftMotorSpeed); // Stepper X is Right, Y is Left
}

void WallFollower::followLeftWall(float targetDistance) {
    if (millis() - lastTime < LOOP_INTERVAL_MS) return;
    lastTime = millis();

    distanceSensors.update();

    float frontDist = distanceSensors.getDistance(4);
    float backDist  = distanceSensors.getDistance(3);

    Serial.println(frontDist);
    Serial.println(backDist);
    

    if (frontDist >= 29.0f && backDist >= 29.0f) {
        steppers.setSpeed(baseSpeed, baseSpeed);
        return;
    }

    float currentDistance = (frontDist + backDist) / 2.0f;
    float angleDiff = frontDist - backDist; 
    float angleWeight = 2.0f; 

    // Trick PID to steer left if pointing away from the wall
    float fusedMeasurement = currentDistance + (angleDiff * angleWeight);

    float steering = wallPid.update(targetDistance, fusedMeasurement);

    float leftMotorSpeed  = baseSpeed - steering;
    float rightMotorSpeed = baseSpeed + steering;
    Serial.print("steering: ");
    Serial.print(steering);

    Serial.print("Left Speed: ");
    Serial.print(leftMotorSpeed);
    
    Serial.print("; Right Speed: ");
    Serial.println(rightMotorSpeed);

    clampMotorSpeeds(leftMotorSpeed, rightMotorSpeed);
    steppers.setSpeed(rightMotorSpeed, leftMotorSpeed);
}

void WallFollower::updateSteppers() {
    steppers.runMotors();
}

void WallFollower::clampMotorSpeeds(float& left, float& right) {
    if (left > 1000)  left = 1000;
    if (left < -1000) left = -1000;
    if (right > 1000)  right = 1000;
    if (right < -1000) right = -1000;
}