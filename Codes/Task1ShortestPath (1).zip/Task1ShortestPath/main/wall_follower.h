#ifndef WALL_FOLLOWER_H
#define WALL_FOLLOWER_H

#include <Arduino.h>
#include "stepper_motor.h"
#include "sharp_ir_array.h"
#include "PID.h"

class WallFollower {
public:
    // Constructor requires both motors and distance sensors
    WallFollower(STEPPERcontroller& motorRef, SharpIRArray& irArrayRef);

    void init();
    
    // Dedicated functions for left and right walls
    void followRightWall(float targetDistance);
    void followLeftWall(float targetDistance);
    
    // Call this to physically step the motors after calculating speeds
    void updateSteppers();

private:
    STEPPERcontroller& steppers;
    SharpIRArray& distanceSensors;
    PIDController wallPid;

    float baseSpeed;
    unsigned long lastTime;
    const float LOOP_INTERVAL_MS = 0.01;   //5
    const float LOOP_DT = 0.000001f;    //0.005

    void clampMotorSpeeds(float& left, float& right);
};

#endif