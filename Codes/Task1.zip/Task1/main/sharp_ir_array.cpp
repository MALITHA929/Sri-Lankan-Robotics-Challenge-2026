#include "sharp_ir_array.h"

// Constructor
SharpIRArray::SharpIRArray(const int pins[], int count) {
    _count = count;
    if (_count > MAX_SHARP_SENSORS) _count = MAX_SHARP_SENSORS;

    for (int i = 0; i < _count; i++) {
        _pins[i] = pins[i];
        _smoothedVoltage[i] = 0.0f; 
    }
}

void SharpIRArray::init() {
    for (int i = 0; i < _count; i++) {
        pinMode(_pins[i], INPUT);
        
    }
}

void SharpIRArray::update() {
    for (int i = 0; i < _count; i++) {
        float distanceSum = 0.0f;
        for (int j = 0; j < 5; j++) {
            // 1. Get raw reading and convert to voltage
            int raw = analogRead(_pins[i]);
            float voltage = raw * (5.0f / 1023.0f);

            // Prevent math errors if voltage drops to 0
            if (voltage < 0.01f) voltage = 0.01f;

            // 2. Calculate distance immediately
            float distance = 5.2819f * pow(voltage, -1.161f);
            
            // 3. Add to the total sum
            distanceSum += distance;

            //delay(2);
        }
        
        // 4. Calculate the average distance and store it
        // (Reusing this variable to hold the final distance)
        _smoothedVoltage[i] = distanceSum / 5.0f;
        //Serial.println(_smoothedVoltage[i]);
    }
}

float SharpIRArray::getDistance(int index) {
    if (index < 0 || index >= _count) return 30.0f; // Out of bounds safety

    // Since we already calculated the average distance in update(), 
    // we just return it directly here.
        float finalDistance = _smoothedVoltage[index];

    // Optional: Clamp the values to the sensor's physical limits
     if (finalDistance > 30.0f) finalDistance = 30.0f;
     if (finalDistance < 2.0f) finalDistance = 2.0f;

    // Serial.println(finalDistance);
    
    return finalDistance;
}

bool SharpIRArray::detectFrontWall(){

    float distance = getDistance(0);

    if (distance < 10.0f) return true;
    return false; 
}

bool SharpIRArray::detectEntrance(bool rightWall, bool front){
    int sensor;

    if (rightWall){
        if (front) {sensor = 2;}
        else {sensor = 1;}
        // sensor = 2;
    }else{
        if (front) {sensor = 4;}
        else {sensor = 3;}
    }

    float distance = getDistance(sensor);

    Serial.println(distance);
    if (distance >= 30.0f) return true;
    return false;
}