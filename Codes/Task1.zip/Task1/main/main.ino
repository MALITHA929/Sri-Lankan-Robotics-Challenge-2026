#include "wall_follower.h"
#include "sharp_ir_array.h"
#include "stepper_motor.h"

const int sharpPins[] = {A8, A9, A10, A11, A12};


SharpIRArray distanceSensors(sharpPins, 5);
STEPPERcontroller motors;

WallFollower wallFollow(motors, distanceSensors);

// Parametes for navigation
bool start = true;
int step = 1;


void setup() {
  Serial.begin(115200);

  motors.init();
  distanceSensors.init(); 
  wallFollow.init();

}

void loop() {
  if (step == 1){
    
    // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

    // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Front wall is detected
      delay(100);

      motors.runBackward(100, 200);
      delay(100);
      // motors.turnRight180();
      motors.turnRight90();
      delay(100);

      distanceSensors.update();
      float dist = distanceSensors.getDistance(0);

      while (dist > 12.0f || dist < 10.0f){
        if (dist > 12.0f) motors.setSpeed(100, 100);
        else if (dist < 10.0f) motors.setSpeed(-100, -100);

        motors.runMotors();

        delay(5);
      
      distanceSensors.update();
      dist = distanceSensors.getDistance(0);
      }
      // motors.runBackward(100, 100);
      delay(100);

       motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 2;
      delay(100);
      
    }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(7.5f);
      wallFollow.updateSteppers();  
    }
    

  }else if (step == 2){

     // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

    // Follow the wall until the gate to the next area is found
    if (distanceSensors.detectEntrance(true, false) && distanceSensors.detectEntrance(true, true)){

      // Gate is found => go to next step
      delay(100);
      motors.runForward(100, 30);
      delay(100);

      motors.turnRight90();
      delay(100);

      step = 3;
      start = true;
    } else{

      // Gate is not yet found => Follow the wall
      wallFollow.followLeftWall(14.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 3){
      // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

    if (distanceSensors.getDistance(3) < 20.0f){
      // delay(100);
      // motors.runForward(100, 100);
      // delay(100);
      // motors.turnRight90();
      // delay(100);

      while (!distanceSensors.detectFrontWall()){
          wallFollow.followLeftWall(14.0f);
      wallFollow.updateSteppers();  
      }

       motors.turnRight90();
      delay(100);

      step = 4;
      start = true;
    }else{
      motors.setSpeed(100, 100);
      motors.runMotors();
      delay(5);

      distanceSensors.update();
    }


  }else if (step == 4){
       // Initial distance sensor reading
    if (start) {
      distanceSensors.update();

      while (!(distanceSensors.getDistance(1) < 20.0f)){
        motors.setSpeed(100, 100);
        motors.runMotors();

        delay(5);
        distanceSensors.update();

      }
      start = false;
    }

    if (distanceSensors.detectFrontWall()){
        motors.runBackward(100, 100);
        delay(100);
        motors.turnLeft90();
        delay(100);

        step = 5;
        start = true;

    }else{
       wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers(); 
    }


  }else if (step == 5){
        // Initial distance sensor reading
    if (start) {
      distanceSensors.update();
      start = false;
    }

      if (distanceSensors.detectEntrance(true, true)){
        motors.runForward(100, 350);
        delay(100);
        motors.turnLeft90();
        delay(100);

        step = 6;
        start = true;

    }else{
       wallFollow.followLeftWall(9.0f);
      wallFollow.updateSteppers(); 
    }


  }else if (step == 6){
          // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Front wall is detected
      delay(100);

      motors.runBackward(100, 100);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 7;
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 7){

         // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Front wall is detected
      delay(100);

      motors.runBackward(100, 200);
      delay(100);
      motors.turnRight180();
      delay(100);
      // Go to the next step
      start = true;
      step = 8;
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 8){
         // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Front wall is detected
      delay(100);

      motors.runBackward(100, 100);
      delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 9;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(16.0f);
      wallFollow.updateSteppers();  
    }
    
  }else if (step == 9){

        // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Front wall is detected
      delay(100);

      motors.runForward(100, 300);
      delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 10;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 10){
        // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Front wall is detected
      delay(100);

      motors.runBackward(100, 200);
      delay(100);
      motors.turnRight180();
      delay(100);
      // Go to the next step
      start = true;
      step = 11;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 11){

       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, false)){

      // Entrance is detected
      delay(100);

      motors.runForward(100, 70);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 12;
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 12){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();

        while (distanceSensors.getDistance(1) >= 30.0f){
          motors.setSpeed(100, 100);
          motors.runMotors();
          delay(5);
          distanceSensors.update();

        }

         motors.runForward(100, 200);
      distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the gate is detected
    if (distanceSensors.detectEntrance(false, false)){

      // Front wall is detected
      delay(100);

      // motors.runForward(100, 50);
      // delay(100);
      motors.turnLeft90();
      delay(100);

      // distanceSensors.update();
      // while (distanceSensors.getDistance(2) >= 30.0f){
      //   motors.setSpeed(100, 100);
      //   motors.runMotors();
      //   delay(5);
      //   distanceSensors.update();
      // }

     
      // Go to the next step
      start = true;
      step = 13;
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 13){
      // Initial distance sensor reading
      if (start) {
        distanceSensors.update();

        //  distanceSensors.update();
      while (distanceSensors.getDistance(2) >= 30.0f){
        motors.setSpeed(100, 100);
        motors.runMotors();
        delay(5);
        distanceSensors.update();
      }

        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      motors.runBackward(100, 70);
      delay(100);
      motors.turnLeft90();
      delay(100);

      distanceSensors.update();
      while (!distanceSensors.detectEntrance(true, true)){
        wallFollow.followRightWall(15.0f);
        wallFollow.updateSteppers();  
      }
      // Go to the next step
      start = true;
      step = 14;
      }else{


      motors.setSpeed(100, 100);
      motors.runMotors();
      delay(5);
      distanceSensors.update();  
    }


  }else if (step == 14){

       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      // motors.runForward(100, 100);
      // delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 15;
      }else{

      // Front wall is not yet detected
      motors.setSpeed(100, 100);
      motors.runMotors();
      delay(5);

      distanceSensors.update(); 
    }

  // }else if (step == 15){
  //      // Initial distance sensor reading
  //     if (start) {
  //       distanceSensors.update();
  //       start = false;
  //   }

  //     // Follow the right wall until the front wall is detected
  //   if (distanceSensors.detectEntrance(false, true)){

  //     // Entrance is detected
  //     delay(50);

  //     motors.runForward(100, 200);
  //     delay(50);
  //     motors.turnLeft90();
  //     delay(50);
  //     // Go to the next step
  //     start = true;
  //     step = 16;
  //     }else{

  //     // Front wall is not yet detected
  //     wallFollow.followLeftWall(8.0f);
  //     wallFollow.updateSteppers();  
  //   }

  }else if (step == 15){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Entrance is detected
      delay(100);

      motors.runForward(100, 200);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 16;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 16){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      motors.runBackward(100, 200);
      delay(100);
      motors.turnRight180();
      delay(100);
      // Go to the next step
      start = true;
      step = 17;
      }else{

      // Front wall is not yet detected
      wallFollow.followRightWall(6.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 17){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      motors.runBackward(100, 100);
      delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 18;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(15.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 18){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Entrance is detected
      delay(100);

      motors.runForward(100, 200);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 19;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 19){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      // motors.runForward(100, 100);
      // delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 20;
      }else{


      motors.setSpeed(100, 100);
      motors.runMotors();
      delay(5);

      distanceSensors.update(); 
    }

  }else if (step == 20){
      // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Entrance is detected
      delay(100);

     
      motors.runForward(100, 200);
      delay(100);
      
      motors.turnLeft90();
      delay(100);

      distanceSensors.update();
      // long i = 0;
      while (distanceSensors.getDistance(3) >= 30.0f || distanceSensors.getDistance(4) >= 30.0f){
        wallFollow.followRightWall(15.0f);
        wallFollow.updateSteppers();

        // i++;
      }

      motors.runBackward(100, 700);
      // motors.runForward(100, 800);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 21;
      }else{

      // Front wall is not yet detected
      wallFollow.followLeftWall(10.0f);
      wallFollow.updateSteppers();  
    }

  }else if (step == 21){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();

        while (distanceSensors.getDistance(3) >= 30.0f){
              motors.setSpeed(100, 100);
              motors.runMotors();
              delay(5);

              distanceSensors.update();
        }
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectFrontWall()){

      // Entrance is detected
      delay(100);

      motors.runBackward(100, 100);
      delay(100);
      motors.turnRight180();
      delay(100);
      // Go to the next step
      start = true;
      step = 22;
      }else{


      // Front wall is not yet detected
      wallFollow.followLeftWall(15.0f);
      wallFollow.updateSteppers();

    
    }
    
  }else if (step == 22){
       // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(true, true)){

      // Entrance is detected
      delay(100);

      motors.runForward(100, 300);
      delay(100);
      motors.turnRight90();
      delay(100);
      // Go to the next step
      start = true;
      step = 23;
      }else{

        // Front wall is not yet detected
      wallFollow.followRightWall(15.0f);
      wallFollow.updateSteppers();
       
    }
    
  }else if (step == 23){
      // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Entrance is detected
      delay(100);

      motors.runForward(100, 200);
      delay(100);
      motors.turnLeft90();
      delay(100);
      // Go to the next step
      start = true;
      step = 24;
      }else{

        // Front wall is not yet detected
      wallFollow.followLeftWall(15.0f);
      wallFollow.updateSteppers();
       
    }
    
  }else if (step == 24){
      // Initial distance sensor reading
      if (start) {
        distanceSensors.update();
        start = false;
    }

      // Follow the right wall until the front wall is detected
    if (distanceSensors.detectEntrance(false, true)){

      // Go to the next step
      start = true;
      step = 25;
      }else{

        // Front wall is not yet detected
      wallFollow.followLeftWall(15.0f);
      wallFollow.updateSteppers();
       
    }
    
  }else if (step == 25){
    
  }

}
